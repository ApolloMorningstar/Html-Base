import './App.css'
import Header from './componentes/Header'

function App() {
  

  return (

      <div>
        <Header />
      <section>
        <img src="./desenho.jpg" alt="" />
        <legend> 1° Mandamento : Subjuguem os fracos e obedeçam os fortes</legend>
      </section>
    <section>
      <h2>Sobre</h2>
      <p>Seja bem-vindo à minha primeira página de fato no react</p>
    </section>
    </div>
  )
}

export default App
